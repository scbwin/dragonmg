##cocos2d_lua_snippets

A collection of Sublime Text 2 snippets & functions to be used with cocos2d-x lua. Most snippets are to be used specifically with .lua

### Installation:
Install with Package Control

### Tab Triggers:

e.g:

- "CCSprite_setPosition" => setPosition(CCPoint_pos)"
- "CCSprite_create" => "CCSprite:create(const_char_*pszFileName)"
