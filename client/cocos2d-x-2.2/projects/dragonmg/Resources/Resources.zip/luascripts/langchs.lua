str_font0 = "hycc.ttf"
--UI\LayerLogin\LayerLogin.lua
str_LayerLogin0 = "账号或密码不能为空"
str_LayerLogin1 = "用户名或密码包含非法字符!"
str_LayerLogin2 = "V1.3"
--UI\CommonUI\CustomPop
str_CustomPop0 = "提 示"